import { useEffect, useRef, useCallback } from 'react'

interface PerformanceMetrics {
  renderCount: number
  lastRenderTime: number
  averageRenderTime: number
  memoryUsage?: number
}

export const usePerformanceMonitor = (componentName: string) => {
  const renderCountRef = useRef(0)
  const renderTimesRef = useRef<number[]>([])
  const startTimeRef = useRef<number>(0)

  // Start timing before render
  const startRender = useCallback(() => {
    startTimeRef.current = performance.now()
  }, [])

  // End timing after render
  const endRender = useCallback(() => {
    const endTime = performance.now()
    const renderTime = endTime - startTimeRef.current
    
    renderCountRef.current += 1
    renderTimesRef.current.push(renderTime)
    
    // Keep only last 10 render times for average calculation
    if (renderTimesRef.current.length > 10) {
      renderTimesRef.current.shift()
    }

    // Log performance warnings
    if (renderTime > 16) { // More than one frame (60fps)
      console.warn(`${componentName} render took ${renderTime.toFixed(2)}ms (>16ms)`)
    }

    if (renderCountRef.current % 50 === 0) {
      const avgRenderTime = renderTimesRef.current.reduce((a, b) => a + b, 0) / renderTimesRef.current.length
      console.log(`${componentName} performance: ${renderCountRef.current} renders, avg ${avgRenderTime.toFixed(2)}ms`)
    }
  }, [componentName])

  // Get current metrics
  const getMetrics = useCallback((): PerformanceMetrics => {
    const avgRenderTime = renderTimesRef.current.length > 0 
      ? renderTimesRef.current.reduce((a, b) => a + b, 0) / renderTimesRef.current.length 
      : 0

    const metrics: PerformanceMetrics = {
      renderCount: renderCountRef.current,
      lastRenderTime: renderTimesRef.current[renderTimesRef.current.length - 1] || 0,
      averageRenderTime: avgRenderTime
    }

    // Add memory usage if available
    if ('memory' in performance) {
      metrics.memoryUsage = (performance as any).memory.usedJSHeapSize
    }

    return metrics
  }, [])

  // Monitor memory leaks
  useEffect(() => {
    const checkMemory = () => {
      if ('memory' in performance) {
        const memory = (performance as any).memory
        const usedMB = Math.round(memory.usedJSHeapSize / 1024 / 1024)
        
        if (usedMB > 100) { // More than 100MB
          console.warn(`${componentName} high memory usage: ${usedMB}MB`)
        }
      }
    }

    const interval = setInterval(checkMemory, 30000) // Check every 30 seconds
    return () => clearInterval(interval)
  }, [componentName])

  // Call this at the start of your component render
  startRender()

  // Call this at the end of your component render (in useEffect)
  useEffect(() => {
    endRender()
  })

  return { getMetrics }
}

// Hook for detecting slow operations
export const useSlowOperationDetector = () => {
  const detectSlowOperation = useCallback((operation: () => Promise<any>, name: string, threshold = 1000) => {
    return async (...args: any[]) => {
      const start = performance.now()
      try {
        const result = await operation(...args)
        const duration = performance.now() - start
        
        if (duration > threshold) {
          console.warn(`Slow operation detected: ${name} took ${duration.toFixed(2)}ms`)
        }
        
        return result
      } catch (error) {
        const duration = performance.now() - start
        console.error(`Operation failed: ${name} took ${duration.toFixed(2)}ms`, error)
        throw error
      }
    }
  }, [])

  return { detectSlowOperation }
}

// Hook for debouncing expensive operations
export const useDebounce = <T extends (...args: any[]) => any>(
  callback: T,
  delay: number
): T => {
  const timeoutRef = useRef<NodeJS.Timeout>()

  const debouncedCallback = useCallback((...args: Parameters<T>) => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current)
    }

    timeoutRef.current = setTimeout(() => {
      callback(...args)
    }, delay)
  }, [callback, delay]) as T

  useEffect(() => {
    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current)
      }
    }
  }, [])

  return debouncedCallback
}