import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://xzhzyevxktpnzriysvmg.supabase.co'
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inh6aHp5ZXZ4a3RwbnpyaXlzdm1nIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTM1MjE2MjgsImV4cCI6MjA2OTA5NzYyOH0.KTGSzRqAjErbGslxjLinsqnWLNlEJ8_4ZTiD0mZSf7M'

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true
  }
})

// Database types
export interface UserProfile {
  id: string
  full_name: string
  created_at: string
  updated_at: string
}

export interface UserProgress {
  id: string
  user_id: string
  week_number: number
  activity_id: string
  completed: boolean
  completed_at: string | null
  created_at: string
}

export interface WeekCompletion {
  id: string
  user_id: string
  week_number: number
  completed: boolean
  completed_at: string | null
  created_at: string
}

// Helper functions
export const calculateOverallProgress = async (userId: string): Promise<number> => {
  const { data: completedWeeks } = await supabase
    .from('week_completions')
    .select('week_number')
    .eq('user_id', userId)
    .eq('completed', true)
  
  return completedWeeks ? (completedWeeks.length / 8) * 100 : 0
}

export const fetchWeekProgress = async (userId: string, weekNumber: number): Promise<UserProgress[]> => {
  const { data, error } = await supabase
    .from('user_progress')
    .select('*')
    .eq('user_id', userId)
    .eq('week_number', weekNumber)
  
  if (error) throw error
  return data || []
}

export const fetchCompletedWeeks = async (userId: string): Promise<number[]> => {
  const { data, error } = await supabase
    .from('week_completions')
    .select('week_number')
    .eq('user_id', userId)
    .eq('completed', true)
  
  if (error) throw error
  return data ? data.map(w => w.week_number) : []
}

export const handleActivityComplete = async (
  userId: string,
  weekNumber: number,
  activityId: string,
  completed: boolean
): Promise<void> => {
  const { error } = await supabase
    .from('user_progress')
    .upsert({
      user_id: userId,
      week_number: weekNumber,
      activity_id: activityId,
      completed: completed,
      completed_at: completed ? new Date().toISOString() : null
    })
  
  if (error) throw error
}

export const getWeekActivityCount = (weekNumber: number): number => {
  // Each week has 4-5 activities
  const activityCounts: Record<number, number> = {
    1: 5, // Foundation & Self-Assessment
    2: 4, // Resume & Application Strategy
    3: 5, // Technical Skills Development
    4: 4, // Behavioral Interview Mastery
    5: 5, // Mock Interview Practice
    6: 4, // Advanced Interview Techniques
    7: 4, // Final Preparations
    8: 4  // Post-Interview & Follow-up
  }
  
  return activityCounts[weekNumber] || 4
}

export const checkWeekCompletion = async (weekNumber: number, userId: string): Promise<boolean> => {
  const { data: activities } = await supabase
    .from('user_progress')
    .select('*')
    .eq('user_id', userId)
    .eq('week_number', weekNumber)
  
  const totalActivities = getWeekActivityCount(weekNumber)
  const completedActivities = activities ? activities.filter(a => a.completed).length : 0
  
  return completedActivities === totalActivities
}

export const markWeekComplete = async (weekNumber: number, userId: string): Promise<void> => {
  const { error } = await supabase
    .from('week_completions')
    .upsert({
      user_id: userId,
      week_number: weekNumber,
      completed: true,
      completed_at: new Date().toISOString()
    })
  
  if (error) throw error
}